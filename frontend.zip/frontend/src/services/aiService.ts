// src/services/aiService.ts
const API_BASE = 'http://localhost:5000/api';


export class AIService {
  private static async callBackendAI(prompt: string): Promise<any> {
  const response = await fetch(`${API_BASE}/ai/improve-proposal`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ idea: prompt })
  });

  if (!response.ok) {
    throw new Error(`Backend error: ${response.status}`);
  }

  return await response.json();
}
  

  private static getMockResponse(prompt: string): string {
    // Your existing mock responses as fallback
    const responses: { [key: string]: string } = {
      'study platform': `🚀 **Elevator Pitch**: "StudySync - An AI-powered platform that creates personalized study plans and connects students with compatible study partners based on courses, learning styles, and schedules."

🎯 **Problem-Solution**: 
- **Problem**: Students struggle with consistent study habits and finding reliable study partners
- **Solution**: AI-driven matching system + personalized study roadmap

💡 **Key Value Propositions**:
1. Smart matching algorithm for study partners
2. AI-generated study schedules
3. Progress tracking and analytics
4. Campus-focused community`,

      'marketplace': `🚀 **Elevator Pitch**: "CampusTrade - A peer-to-peer marketplace exclusively for college students to buy, sell, and trade textbooks, electronics, and campus essentials safely within their university ecosystem."

🎯 **Problem-Solution**:
- **Problem**: Students overpay for textbooks and struggle to sell used items
- **Solution**: Campus-verified marketplace with secure transactions

💡 **Key Value Propositions**:
1. University email verification for safety
2. Price comparison with campus bookstore
3. Delivery coordination for large items
4. Semester-based timing alerts`,

      'food delivery': `🚀 **Elevator Pitch**: "DormEats - A late-night food delivery service operated by students for students, focusing on campus locations and student budget-friendly options when regular services are closed."

🎯 **Problem-Solution**:
- **Problem**: Limited late-night food options on campus
- **Solution**: Student-run delivery with campus dining partnerships

💡 **Key Value Propositions**:
1. Student employment opportunities
2. Late-night service (10 PM - 2 AM)
3. Campus dining integration
4. Affordable student pricing`
    };

    // Find the best matching response based on keywords
    const lowerPrompt = prompt.toLowerCase();
    let bestMatch = 'study platform'; // default
    
    if (lowerPrompt.includes('marketplace') || lowerPrompt.includes('buy') || lowerPrompt.includes('sell')) {
      bestMatch = 'marketplace';
    } else if (lowerPrompt.includes('food') || lowerPrompt.includes('delivery') || lowerPrompt.includes('eat')) {
      bestMatch = 'food delivery';
    } else if (lowerPrompt.includes('study') || lowerPrompt.includes('learn') || lowerPrompt.includes('education')) {
      bestMatch = 'study platform';
    }

    return responses[bestMatch] || `Based on your idea "${prompt}", here's my analysis:

🚀 **Refined Pitch**: Focus on solving a specific problem for college students with a clear, scalable solution.

🎯 **Key Recommendations**:
1. Clearly define your target user persona
2. Identify your unique competitive advantage
3. Outline a realistic monetization strategy
4. Consider campus-specific challenges and opportunities

💡 **Next Steps**:
- Conduct market research with fellow students
- Create a minimum viable product (MVP)
- Test your assumptions with real users`;
  }

static async generateBusinessName(idea: string): Promise<string[]> {
  const data = await this.callBackendAI(idea);
  return data.businessNames || [];
}

static async improveProposal(idea: string) {
  return this.callBackendAI(idea);
}
static async analyzeIdea(idea: string) {
  return await this.callBackendAI(idea);
}

}