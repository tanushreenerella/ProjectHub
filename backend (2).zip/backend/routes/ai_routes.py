from flask import Blueprint, request, jsonify
from extensions import openai_client
import json

ai_bp = Blueprint("ai", __name__)

@ai_bp.route("/improve-proposal", methods=["POST"])
def improve_proposal():
    idea = request.json.get("idea")

    prompt = f"""
You are a startup mentor AI.

Analyze this startup idea:
"{idea}"

Return ONLY valid JSON in this exact format:

{{
  "feedback": "detailed paragraph feedback",
  "score": 1-10,
  "strengths": ["point1", "point2", "point3"],
  "improvements": ["point1", "point2", "point3"],
  "businessNames": ["name1", "name2", "name3", "name4", "name5"]
}}
"""

    response = openai_client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        max_tokens=600,
        temperature=0.7
    )

    content = response.choices[0].message.content

    try:
        parsed = json.loads(content)
        return jsonify(parsed)
    except:
        return jsonify({
            "feedback": content,
            "score": 7,
            "strengths": [],
            "improvements": [],
            "businessNames": []
        })
